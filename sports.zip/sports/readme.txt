1.引用包的作用
    flask用于制作dashboard显示网页
    requests用于爬取数据

2.config.json配置文件的作用
    定义做比对的球员信息及比赛场次信息

3.前端使用
    jQuery 用于动态js
    bootstrap 快速布局前端页面
    echarts.js 用来制作雷达图